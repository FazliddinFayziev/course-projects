from DoublyLinkedList import DoublyLinkedList

if __name__ == '__main__':
    myList = DoublyLinkedList()

    # Personalize the list shown below to make your own To-Do List (30 Points).
    myList.insertNodeAtRear('Finish Assignment')
    myList.insertNodeAtRear('Review Lecture Notes')
    myList.insertNodeAtRear('Do Laundry')
    myList.insertNodeAtRear('Cook Dinner')
    myList.insertNodeAtRear('Call Family')
    myList.insertNodeAtRear('Plan Tomorrow')

    myList.traverseLinkedList()

    myList.insertNodeAtFront('Check Calendar')

    myList.traverseLinkedList()

    print(f"Head: {myList.head.getData()}")
    print(f"Tail: {myList.tail.getData()}")


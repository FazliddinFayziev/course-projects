from DoubleLinkNode import DoubleLinkNode


class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def insertNodeAtRear(self, item):
        myNode = DoubleLinkNode(item)
        if self.head is None and self.tail is None:
            self.head = myNode
            self.tail = myNode
        else:
            myNode.setPrevious(self.tail)   # Link the new node's previous to the current tail
            self.tail.setNext(myNode)       # Link the current tail's next to the new node
            self.tail = myNode              # Update the tail to the new node

    def insertNodeAtFront(self, item):
        myNode = DoubleLinkNode(item)
        if self.head is None and self.tail is None:
            self.head = myNode
            self.tail = myNode
        else:
            myNode.setNext(self.head)       # Link the new node's next to the current head
            self.head.setPrevious(myNode)   # Link the current head's previous to the new node
            self.head = myNode              # Update the head to the new node

    def traverseLinkedList(self):
        length = 140
        print("+" * length)
        print("Exploring the Doubly Linked List: ")
        print("+" * length)
        temp = self.head
        while True:
            if temp is None:
                break
            else:
                print(temp, end='')
                temp = temp.getNext()
        print('\n' + "+" * length)
